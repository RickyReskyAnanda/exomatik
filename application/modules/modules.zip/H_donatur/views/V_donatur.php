      <section class="page-header">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <ul class="breadcrumb">
                <li><a href="portofolio.html">Home</a></li>
              </ul>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <h1>Donatur</h1>
            </div>
          </div>
        </div>
      </section>
      <!-- Bagian isi  -->
      <div class="container" style="padding-top: 10px">
        <h2>Daftar Donatur Exomatik</h2>
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>
                No
              </th>
              <th>
                Tanggal Pengiriman
              </th>
              <th>
                Nama Donatur
              </th>
              <th>
                Pekerjaan
              </th>
              <th>
                Jenis Pengiriman
              </th>
              <th>
                Jumlah Sumbangan
              </th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
                1
              </td>
              <td>
                Mark
              </td>
              <td>
                Otto
              </td>
              <td>
                kredit
              </td>
              <td>
                100.000
              </td>
              <td>
                04-06-2017
              </td>
            </tr>
            <tr>
              <td>
                2
              </td>
              <td>
                Jacob
              </td>
              <td>
                Thornton
              </td>
              <td>
                kredit
              </td>
              <td>
                100.000
              </td>
              <td>
                04-06-2017
              </td>
            </tr>
            <tr>
              <td>
                3
              </td>
              <td>
                Larry
              </td>
              <td>
                the Bird
              </td>
              <td>
                kredit
              </td>
              <td>
                100.000
              </td>
              <td>
                04-06-2017
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <!-- batas Donatur -->  