      <!-- Batas Header --> 
      <section class="page-header">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <ul class="breadcrumb">
                <li><a href="portofolio.html">Home</a></li>
              </ul>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <h1>Profil</h1>
            </div>
          </div>
        </div>
      </section>
      <!-- Bagian isi  -->
      <div style="margin-top: -35px;margin-bottom: -40px">
        <section class="parallax section section-parallax " data-stellar-background-ratio="0.5" style="background-image: url(&quot;img/parallax-transparent.jpg&quot;); background-position: 0% -36.5px;">
          <div class="container">
            <div class="row">
              <div class="col-md-8 col-md-offset-2">
                <center>
                <h2 class="mb-none text-dark">Visi dan Misi<br>Exomatik Study Club Periode<br>2016/2017</h2>
                </center>
                <h4>Visi :</h4>
                <p class="mb-none">Menyukseskan kegiatan belajar mengajar pada lingkup internal maupun eksternal Universitas khususnya yang berdasarkan IT (Information Technology), serta mencerdaskan anggota Study Club khususnya mahasiswa Teknik Informatika dan Sistem Informasi UIN ALAUDDIN MAKASSAR sehingga dapat mencapai tujuan bersama dalam bidang Akademisi.
                </p>
                <h4>Misi :</h4>
                <ol>
                  <li>Memberikan Pengetahuan terhadap seluruh anggota Exomatik dalam proses berorganisasi.</li>
                  <li>Menjadikan Study Club Exomatik dapat eksis tidak hanya dalam lingkup jurusan, tetapi juga dalam lingkup Universitas maupun Masyarakat.</li>
                  <li>Menjadi barometer Study Club dalam lingkup Jurusan Teknik Informatika dan Sistem Informasi.</li>
                  <li>Merekatkan Kekeluargaan antara mahasiswa.</li>
                  <li>Menciptakan insan-insan yang mampu besaing dalam bidang IT (Information Technology)di Internal Univesitas maupun Eksternal.</li>
                  <li>Menjadiakan seluruh anggota yang berintelektual dalam bidang IT (Information Technology)dan dapat bertanggung jawab dalam bidang tersebut.</li>
                </ol>
              </div>
            </div>
          </div>
        </section>
      </div>
      <!-- batas sejarah -->  