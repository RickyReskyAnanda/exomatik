 			<!-- awal footer -->
			<footer id="footer">
				<div class="container">
					<div class="row">
						<div class="footer-ribbon">
							<span>Exomatik Study Club</span>
						</div>
						<div class="col-md-3">
							<div class="newsletter">
								<h4>HUBUNGI KAMI</h4>
								<p style="font-size: 16px; font: Open Sans"><i class="fa fa-phone-square"></i>  +6285796782236</p>
								<p style="font-size: 16px; font: Open Sans"><i class="fa fa-envelope-o"></i>  crewexomatik@gmail.com</p>
							</div>
						</div>
						<div class="col-md-3">
							<h4>MEDIA SOSIAL</h4>
							<p style="font-size: 16px; font: Open Sans"><i class="fa fa-facebook-official"></i>  Facebook</p>
							<p style="font-size: 16px; font: Open Sans"><i class="fa fa-twitter-square"></i>  Twiter</p>
							<p style="font-size: 16px; font: Open Sans"><i class="fa fa-instagram"></i>  Instagram</p>
						</div>
						<div class="col-md-3">
								<h4>OUR PARTNERS</h4>
								
						</div>
						<div class="col-md-3">
							<h4>MENU NAVBAR</h4>
							<p style="font-size: 16px; font: Open Sans ">  Portofolia</p>
							<p style="font-size: 16px; font: Open Sans">  Tutorial</p>
							<p style="font-size: 16px; font: Open Sans"> Download</p>
						</div>
					</div>
				</div>
				<div class="footer-copyright">
					<div class="container">
						<div class="row">
							<div class="col-md-8">
								<p>© Copyright 2016 Exomatik Study Club. All Rights Reserved.</p>
							</div>
							<div class="col-md-4">
								<nav id="sub-menu">
									<ul>
										<li><a href="beranda.html">Beranda</a></li>
										<li><a href="webdeveloper.html">Web Developer</a></li>
										<li><a href="saran.html">Saran & MAsukan</a></li>
									</ul>
								</nav>
							</div>
						</div>
					</div>
				</div>
			</footer>
		</div>
		<!-- Vendor -->
		<script src="<?=base_url()?>sets/vendor/jquery/jquery.min.js"></script>
		<script src="<?=base_url()?>sets/vendor/jquery.appear/jquery.appear.min.js"></script>
		<script src="<?=base_url()?>sets/vendor/jquery.easing/jquery.easing.min.js"></script>
		<script src="<?=base_url()?>sets/vendor/jquery-cookie/jquery-cookie.min.js"></script>
		<script src="<?=base_url()?>sets/vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="<?=base_url()?>sets/vendor/common/common.min.js"></script>
		<script src="<?=base_url()?>sets/vendor/jquery.validation/jquery.validation.min.js"></script>
		<script src="<?=base_url()?>sets/vendor/jquery.stellar/jquery.stellar.min.js"></script>
		<script src="<?=base_url()?>sets/vendor/jquery.easy-pie-chart/jquery.easy-pie-chart.min.js"></script>
		<script src="<?=base_url()?>sets/vendor/jquery.gmap/jquery.gmap.min.js"></script>
		<script src="<?=base_url()?>sets/vendor/jquery.lazyload/jquery.lazyload.min.js"></script>
		<script src="<?=base_url()?>sets/vendor/isotope/jquery.isotope.min.js"></script>
		<script src="<?=base_url()?>sets/vendor/owl.carousel/owl.carousel.min.js"></script>
		<script src="<?=base_url()?>sets/vendor/magnific-popup/jquery.magnific-popup.min.js"></script>
		<script src="<?=base_url()?>sets/vendor/vide/vide.min.js"></script>
		
		<!-- Theme Base, Components and Settings -->
		<script src="<?=base_url()?>sets/js/theme.js"></script>
		
		<!-- Current Page Vendor and Views -->
		<script src="<?=base_url()?>sets/vendor/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
		<script src="<?=base_url()?>sets/vendor/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
		<script src="<?=base_url()?>sets/vendor/circle-flip-slideshow/js/jquery.flipshow.min.js"></script>
		<script src="<?=base_url()?>sets/js/views/view.home.js"></script>
		<!-- Theme Custom -->
		<script src="<?=base_url()?>sets/js/custom.js"></script>
		<!-- Theme Initialization Files -->
		<script src="<?=base_url()?>sets/js/theme.init.js"></script>
	</body>
</html>