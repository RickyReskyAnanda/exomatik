			<section class="page-header">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<ul class="breadcrumb">
								<li><a href="portofolio.html">Home</a></li>
							</ul>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<h1>Web Developer</h1>
						</div>
					</div>
				</div>
			</section>
			<!-- Bagian isi  -->
			<div class="container">
				<div class="row">
					<span style="font-size: 25px">X-Dev</span> 
					<hr>
					<div class="col-md-8">
						<span class="thumb-info thumb-info-side-image thumb-info-no-zoom">
							<span class="thumb-info-side-image-wrapper">
								<img src="<?=base_url()?>sets/img/exo/lisa.jpg" class="img-responsive" alt="" style="width: 200px;">
							</span>
							<span class="thumb-info-caption">
								<span class="thumb-info-caption-text">
									<strong>Ricky Resky Ananda</strong><br>
									<b>Status :</b> Mahasiswa<br>
									<b>Bidang :</b> Font-End dan Back-End<br>
									<b>Bagian :</b> ------------------<br>
									<ul>
										<li>Mendesain</li>
										<li>Mendesain</li>
										<li>Mendesain</li>
									</ul>
								</span>
							</span>
						</span>
					</div>
				</div>
				<div class="row" style="margin-top: 20px">
					<div class="col-md-8">
						<span class="thumb-info thumb-info-side-image thumb-info-no-zoom">
							<span class="thumb-info-side-image-wrapper">
								<img src="<?=base_url()?>sets/img/exo/lisa.jpg" class="img-responsive" alt="" style="width: 200px;">
							</span>
							<span class="thumb-info-caption">
								<span class="thumb-info-caption-text">
									<strong>Muh. Juanda B</strong><br>
									<b>Status :</b> Mahasiswa<br>
									<b>Bidang :</b> Font-End<br>
									<b>Bagian :</b> ------------------<br>
									<ul>
										<li>Mendesain</li>
										<li>Mendesain</li>
										<li>Mendesain</li>
									</ul>
								</span>
							</span>
						</span>
					</div>
				</div>
				<div class="row" style="margin-top: 20px">
					<div class="col-md-8">
						<span class="thumb-info thumb-info-side-image thumb-info-no-zoom">
							<span class="thumb-info-side-image-wrapper">
								<img src="<?=base_url()?>sets/img/exo/lisa.jpg" class="img-responsive" alt="" style="width: 200px;">
							</span>
							<span class="thumb-info-caption">
								<span class="thumb-info-caption-text">
									<strong>Lindasari</strong><br>
									<b>Status :</b> Mahasiswa<br>
									<b>Bidang :</b> Font-End<br>
									<b>Bagian :</b> ------------------<br>
									<ul>
										<li>Mendesain</li>
										<li>Mendesain</li>
										<li>Mendesain</li>
									</ul>
								</span>
							</span>
						</span>
					</div>
				</div>
				<div class="row" style="margin-top: 20px">
					<div class="col-md-8">
						<span class="thumb-info thumb-info-side-image thumb-info-no-zoom">
							<span class="thumb-info-side-image-wrapper">
								<img src="<?=base_url()?>sets/img/exo/lisa.jpg" class="img-responsive" alt="" style="width: 200px;">
							</span>
							<span class="thumb-info-caption">
								<span class="thumb-info-caption-text">
									<strong>Nurlisah</strong><br>
									<b>Status :</b> Mahasiswa<br>
									<b>Bidang :</b> Font-End<br>
									<b>Bagian :</b> ------------------<br>
									<ul>
										<li>Mendesain</li>
										<li>Mendesain</li>
										<li>Mendesain</li>
									</ul>
								</span>
							</span>
						</span>
					</div>
				</div>
				<div class="row" style="margin-top: 20px">
					<div class="col-md-8">
						<span class="thumb-info thumb-info-side-image thumb-info-no-zoom">
							<span class="thumb-info-side-image-wrapper">
								<img src="<?=base_url()?>sets/img/exo/lisa.jpg" class="img-responsive" alt="" style="width: 200px;">
							</span>
							<span class="thumb-info-caption">
								<span class="thumb-info-caption-text">
									<strong>Fadli Hidayat</strong><br>
									<b>Status :</b> Mahasiswa<br>
									<b>Bidang :</b> Desain <br>
									<b>Bagian :</b> ------------------<br>
									<ul>
										<li>Mendesain</li>
										<li>Mendesain</li>
										<li>Mendesain</li>
									</ul>
								</span>
							</span>
						</span>
					</div>
				</div>
			</div>
			<!-- batas isi -->	