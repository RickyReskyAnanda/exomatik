			<!-- Bagian isi tutorial -->
			<section class="page-header">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<ul class="breadcrumb">
								<li><a href="#">Home</a></li>
								<li><a href="#">Kategori</a></li>
								<li class="active">Web Programming</li>
							</ul>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<h1>Tutorial</h1>
						</div>
					</div>
				</div>
			</section>
			<!-- Batas tutoril -->
			<!-- bagian slider -->
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<div class="row">
							<div class="col-md-12 ">
								<aside class="sidebar">
									<h4 class="heading-primary"><strong>Tutorial</strong> Terbaru</h4>
										<div class="row warnah jarak">
											<div class="col-md-3" style="padding-top: 10px ;margin-left: -8px">
												<a href="#"><img class="img-responsive img-circle mb-lg" src="../sets/img/projects/project-1.jpg" alt="Project Image">
											</div>
											<div class="col-md-9" style="margin-left: -15px">
												<h5 class="heading-primary mb-none">Tutorial cara pengerjaan web berbasis android 112234455</h5>
												<span>Oleh <a href="#" style="color: #000">John Doe</a> </span>
											</div>
										</div>
										<div class="row warnah jarak">
											<div class="col-md-3" style="padding-top: 5px ;margin-left: -8px">
												<a href="#"><img class="img-responsive img-circle mb-lg" src="../sets/img/projects/project-1.jpg" alt="Project Image">
											</div>
											<div class="col-md-9" style="margin-left: -15px">
												<h5 class="heading-primary mb-none">Tutorial cara pengerjaan web berbasis android 112234455</h5>
												<span>Oleh <a href="#" style="color: #000">John Doe</a> </span>
											</div>
										</div>
										<div class="row warnah jarak">
											<div class="col-md-3" style="padding-top: 5px ;margin-left: -8px">
												<a href="#"><img class="img-responsive img-circle mb-lg" src="../sets/img/projects/project-1.jpg" alt="Project Image">
											</div>
											<div class="col-md-9" style="margin-left: -15px">
												<h5 class="heading-primary mb-none">Tutorial cara pengerjaan web berbasis android 112234455</h5>
												<span>Oleh <a href="#" style="color: #000">John Doe</a> </span>
											</div>
										</div>
										<div class="row warnah jarak">
											<div class="col-md-3" style="padding-top: 5px ;margin-left: -8px">
												<a href="#"><img class="img-responsive img-circle mb-lg" src="../sets/img/projects/project-1.jpg" alt="Project Image">
											</div>
											<div class="col-md-9" style="margin-left: -15px">
												<h5 class="heading-primary mb-none">Tutorial cara pengerjaan web berbasis android 112234455</h5>
												<span>Oleh <a href="#" style="color: #000">John Doe</a> </span>
											</div>
										</div>
										<div class="row warnah jarak">
											<div class="col-md-3" style="padding-top: 5px ;margin-left: -8px">
												<a href="#"><img class="img-responsive img-circle mb-lg" src="../sets/img/projects/project-1.jpg" alt="Project Image">
											</div>
											<div class="col-md-9" style="margin-left: -15px">
												<h5 class="heading-primary mb-none">Tutorial cara pengerjaan web berbasis android 112234455</h5>
												<span>Oleh <a href="#" style="color: #000">John Doe</a> </span>
											</div>
										</div>
								</aside>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<aside class="sidebar" style=>
									<h4 class="heading-primary"><strong>Tutorial</strong> Terpopuler</h4>
										<div class="row warnah jarak">
											<div class="col-md-3" style="padding-top: 10px ;margin-left: -8px">
												<a href="#"><img class="img-responsive img-circle mb-lg" src="../sets/img/projects/project-1.jpg" alt="Project Image">
											</div>
											<div class="col-md-9" style="margin-left: -15px">
												<h5 class="heading-primary mb-none">Tutorial cara pengerjaan web berbasis android 112234455</h5>
												<span>Oleh <a href="#" style="color: #000">John Doe</a> </span>
											</div>
										</div>
										<div class="row warnah jarak">
											<div class="col-md-3" style="padding-top: 5px ;margin-left: -8px">
												<a href="#"><img class="img-responsive img-circle mb-lg" src="../sets/img/projects/project-1.jpg" alt="Project Image">
											</div>
											<div class="col-md-9" style="margin-left: -15px">
												<h5 class="heading-primary mb-none">Tutorial cara pengerjaan web berbasis android 112234455</h5>
												<span>Oleh <a href="#" style="color: #000">John Doe</a> </span>
											</div>
										</div>
										<div class="row warnah jarak">
											<div class="col-md-3" style="padding-top: 5px ;margin-left: -8px">
												<a href="#"><img class="img-responsive img-circle mb-lg" src="../sets/img/projects/project-1.jpg" alt="Project Image">
											</div>
											<div class="col-md-9" style="margin-left: -15px">
												<h5 class="heading-primary mb-none">Tutorial cara pengerjaan web berbasis android 112234455</h5>
												<span>Oleh <a href="#" style="color: #000">John Doe</a> </span>
											</div>
										</div>
										<div class="row warnah jarak">
											<div class="col-md-3" style="padding-top: 5px ;margin-left: -8px">
												<a href="#"><img class="img-responsive img-circle mb-lg" src="../sets/img/projects/project-1.jpg" alt="Project Image">
											</div>
											<div class="col-md-9" style="margin-left: -15px">
												<h5 class="heading-primary mb-none">Tutorial cara pengerjaan web berbasis android 112234455</h5>
												<span>Oleh <a href="#" style="color: #000">John Doe</a> </span>
											</div>
										</div>
										<div class="row warnah jarak">
											<div class="col-md-3" style="padding-top: 5px ;margin-left: -8px">
												<a href="#"><img class="img-responsive img-circle mb-lg" src="../sets/img/projects/project-1.jpg" alt="Project Image">
											</div>
											<div class="col-md-9" style="margin-left: -15px">
												<h5 class="heading-primary mb-none">Tutorial cara pengerjaan web berbasis android 112234455</h5>
												<span>Oleh <a href="#" style="color: #000">John Doe</a> </span>
											</div>
										</div>
								</aside>
							</div>
						</div>
					</div>
					<div class="col-md-8">
						<div class="row" >
							<div class="col-md-3">
								<a href="#"><img class="img-responsive img-circle mb-lg" src="../sets/img/projects/project-1.jpg" alt="Project Image">
							</div>
							<div class="col-md-9">
								<div class="post-meta" style="text-align: right;">
									<span><i class="fa fa-calendar"></i> January 10, 2016 </span>
									<span><i class="fa fa-user"></i> Oleh <a href="#">John Doe</a> </span>
								</div>
								<div class="post-info">
									<h4><a href="tutorial-kategori-isi.html">Odiosters Nullam Vitae</a></h4>
								</div>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec hendrerit vehicula est, in consequat libero. Lorem ipsum amet, consectetur adipiscing elit. Donec hendrerit vehicula est, in consequat libero. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec hendrerit vehicula est, in consequat libero. Lorem ipsum amet, consectetur adipiscing elit. Donec hendrerit vehicula est, in consequat libero. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec hendrerit vehicula est, in consequat libero. Lorem ipsum amet, consectetur adipiscing elit. Donec hendrerit vehicula est, in consequat libero. 
								</p>
							</div>
							<div class="col-md-12" style="background-color: #c1bdbd; color : #000 ; padding-bottom: 10px;padding-top: 10px">
								<div class="post-meta">
									<span><a href="#"><i class="fa fa-comments"></i></a> Pesan </span>
									<span><a href="#"><i class="fa fa-thumbs-o-up"></a></i> Like </span>
								</div>
							</div>
						</div>
						<div class="row" style="margin-top: 40px">
							<div class="col-md-3">
								<a href="#"><img class="img-responsive img-circle mb-lg" src="../sets/img/projects/project-1.jpg" alt="Project Image">
							</div>
							<div class="col-md-9">
								<div class="post-meta" style="text-align: right;">
									<span><i class="fa fa-calendar"></i> January 10, 2016 </span> | 
									<span><i class="fa fa-user"></i> Oleh <a href="#">John Doe</a> </span>
								</div>
								<div class="post-info">
									<h4><a href="tutorial-kategori-isi.html">Odiosters Nullam Vitae</a></h4>
								</div>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec hendrerit vehicula est, in consequat libero. Lorem ipsum amet, consectetur adipiscing elit. Donec hendrerit vehicula est, in consequat libero. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec hendrerit vehicula est, in consequat libero. Lorem ipsum amet, consectetur adipiscing elit. Donec hendrerit vehicula est, in consequat libero. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec hendrerit vehicula est, in consequat libero. Lorem ipsum amet, consectetur adipiscing elit. Donec hendrerit vehicula est, in consequat libero. 
								</p>
							</div>
							<div class="col-md-12" style="background-color: #c1bdbd; color : #000; padding-top: 10px; padding-bottom: 10px ">
								<div class="post-meta">
									<span><a href="#"><i class="fa fa-comments"></i></a> Pesan </span>
									<span><a href="#"><i class="fa fa-thumbs-o-up"></a></i> Like </span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- batas slider -->	