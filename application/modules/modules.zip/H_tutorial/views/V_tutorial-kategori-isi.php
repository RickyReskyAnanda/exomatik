			<!-- awal  -->	
			<section class="page-header">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<ul class="breadcrumb">
								<li><a href="tutorial.html">Home</a></li>
								<li><a href="tutorial-kategori.html">Kategori</a></li>
								<li><a href="tutorial-kategori-destopprogramming.html">Destop Programming</a></li>
								<li class="active">Tutorial</li>
							</ul>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<h1>Tutorial</h1>
						</div>
					</div>
				</div>
			</section>
			<!-- batas -->
			<!-- Bagian isi tutorial -->
			<div class="container" style="margin-top: 10px">
				<div class="row">
					<div class="col-md-8">
						<div class="row">
							<div class="post-content">
								<h2><a href="blog-post.html">Class aptent taciti sociosqu ad litora torquen</a></h2>
									<div class="post-meta">
										<span><i class="fa fa-user"></i> By <a href="#">John Doe</a> </span>
										<span><i class="fa fa-tag"></i> <a href="#">Duis</a>, <a href="#">News</a> </span>
										<span><i class="fa fa-comments"></i> <a href="#">12 Comments</a></span>
									</div>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur lectus lacus, rutrum sit amet placerat et, bibendum nec mauris. Duis molestie, purus eget placerat viverra, nisi odio gravida sapien, congue tincidunt nisl ante nec tellus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce sagittis, massa fringilla consequat blandit, mauris ligula porta nisi, non tristique enim sapien vel nisl. Suspendisse vestibulum lobortis dapibus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Praesent nec tempus nibh. Donec mollis commodo metus et fringilla. Etiam venenatis, diam id adipiscing convallis, nisi eros lobortis tellus, feugiat adipiscing ante ante sit amet dolor. Vestibulum vehicula scelerisque facilisis. Sed faucibus placerat bibendum. Maecenas sollicitudin commodo justo, quis hendrerit leo consequat ac. Proin sit amet risus sapien, eget interdum dui. Proin justo sapien, varius sit amet hendrerit id, egestas quis mauris.</p>
										<p>Aenean metus nibh, molestie at consectetur nec, molestie sed nulla. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec euismod urna. Donec gravida pharetra ipsum, non volutpat ipsum sagittis a. Phasellus ut convallis ipsum. Sed nec dui orci, nec hendrerit massa. Curabitur at risus suscipit massa varius accumsan. Proin eu nisi id velit ultrices viverra nec condimentum magna. Ut porta orci quis nulla aliquam at dictum mi viverra. Maecenas ultricies elit in tortor scelerisque facilisis. Mauris vehicula porttitor lacus, vel pretium est semper non. Ut accumsan rhoncus metus non pharetra. Quisque luctus blandit nisi, id tempus tellus pulvinar eu. Nam ornare laoreet mi a molestie. Donec sodales scelerisque congue. </p>
								<span class="thumb-info-social-icons" style="border-top: 0px">
									<a target="_blank" href="#" style="background-color: #0a628e"><i class="fa fa-facebook"></i><span>Facebook</span></a>
									<a href="#"><i class="fa fa-twitter"></i><span>Twitter</span></a>
									<a href="#" style="background-color: #c71603"><i class="fa fa-google-plus"></i><span>Twitter</span></a>
								</span>
							</div>
						<div class="divider divider-style-2 divider-icon-sm taller">
							<i class="fa fa-chevron-down"></i>
						</div>
						</div>
						<div class="row">
							<h2> Tutorial <strong>Terpopuler</strong></h2>
							<div class="lightbox" data-plugin-options='{"delegate": "a", "type": "image", "gallery": {"enabled": true}, "mainClass": "mfp-with-zoom", "zoom": {"enabled": true, "duration": 300}}'>
							<div class="owl-carousel owl-theme stage-margin" data-plugin-options='{"items": 3, "margin": 20, "loop": false, "nav": true, "dots": false, "stagePadding": 40}'>
								<div>
									<a class="img-thumbnail img-thumbnail-hover-icon mb-xs mr-xs" href="../sets/img/projects/project-1.jpg" style="border: 0px">
										<img class="img-responsive" src="../sets/img/projects/project-1.jpg" alt="Project Image">
									</a>
									<h6><a href="blog-post.html">Tutorial menggunakan sublime text dengan boostrap terlengkap dan terbaru.</a></h6>
									<div class="post-meta">
										<span><i class="fa fa-user"></i> Oleh Nurlisah </span>
									</div>
								</div>
								<div>
									<a class="img-thumbnail img-thumbnail-hover-icon mb-xs mr-xs" href="../sets/img/projects/project-1.jpg" style="border: 0px">
										<img class="img-responsive" src="../sets/img/projects/project-1.jpg" alt="Project Image">
									</a>
									<h6><a href="blog-post.html">Tutorial menggunakan sublime text dengan boostrap terlengkap dan terbaru.</a></h6>
									<div class="post-meta">
										<span><i class="fa fa-user"></i> Oleh Nurlisah </span>
									</div>
								</div>
								<div>
									<a class="img-thumbnail img-thumbnail-hover-icon mb-xs mr-xs" href="../sets/img/projects/project-1.jpg" style="border: 0px">
										<img class="img-responsive" src="../sets/img/projects/project-1.jpg" alt="Project Image">
									</a>
									<h6><a href="blog-post.html">Tutorial menggunakan sublime text dengan boostrap terlengkap dan terbaru.</a></h6>
									<div class="post-meta">
										<span><i class="fa fa-user"></i> Oleh Nurlisah </span>
									</div>
								</div>
								<div>
									<a class="img-thumbnail img-thumbnail-hover-icon mb-xs mr-xs" href="../sets/img/projects/project-1.jpg" style="border: 0px">
										<img class="img-responsive" src="../sets/img/projects/project-1.jpg" alt="Project Image">
									</a>
									<h6><a href="blog-post.html">Tutorial menggunakan sublime text dengan boostrap terlengkap dan terbaru.</a></h6>
									<div class="post-meta">
										<span><i class="fa fa-user"></i> Oleh Nurlisah </span>
									</div>
								</div>
								<div>
									<a class="img-thumbnail img-thumbnail-hover-icon mb-xs mr-xs" href="../sets/img/projects/project-1.jpg" style="border: 0px">
										<img class="img-responsive" src="../sets/img/projects/project-1.jpg" alt="Project Image">
									</a>
									<h6><a href="blog-post.html">Tutorial menggunakan sublime text dengan boostrap terlengkap dan terbaru.</a></h6>
									<div class="post-meta">
										<span><i class="fa fa-user"></i> Oleh Nurlisah </span>
									</div>
								</div>
								<div>
									<a class="img-thumbnail img-thumbnail-hover-icon mb-xs mr-xs" href="../sets/img/projects/project-1.jpg" style="border: 0px">
										<img class="img-responsive" src="../sets/img/projects/project-1.jpg" alt="Project Image">
									</a>
									<h6><a href="blog-post.html">Tutorial menggunakan sublime text dengan boostrap terlengkap dan terbaru.</a></h6>
									<div class="post-meta">
										<span><i class="fa fa-user"></i> Oleh Nurlisah </span>
									</div>
								</div>
								<div>
									<a class="img-thumbnail img-thumbnail-hover-icon mb-xs mr-xs" href="../sets/img/projects/project-1.jpg" style="border: 0px">
										<img class="img-responsive" src="../sets/img/projects/project-1.jpg" alt="Project Image">
									</a>
									<h6><a href="blog-post.html">Tutorial menggunakan sublime text dengan boostrap terlengkap dan terbaru.</a></h6>
									<div class="post-meta">
										<span><i class="fa fa-calendar"></i> January 10, 2016 </span>
									</div>
								</div>
							</div>
						</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="row">
							<div class="col-md-12 ">
								<aside class="sidebar">
									<h3 class="heading-primary" style="margin-left: -10px; padding-top: 10px"><strong>Tutorial</strong> Terkait</h3>
										<div class="row warnah jarak">
											<div class="col-md-3" style="margin-left: -8px">
												<a href="#"><img class="img-responsive img-circle mb-lg" src="../sets/img/projects/project-1.jpg" alt="Project Image">
											</div>
											<div class="col-md-9" style="margin-left: -10px">
												<h5 class="heading-primary mb-none">Tutorial cara pengerjaan web berbasis android 112234455</h5>
												<span>Oleh <a href="#" style="color: #000">John Doe</a> </span>
											</div>
										</div>
										<div class="row warnah jarak">
											<div class="col-md-3" style="margin-left: -8px">
												<a href="#"><img class="img-responsive img-circle mb-lg" src="../sets/img/projects/project-1.jpg" alt="Project Image">
											</div>
											<div class="col-md-9" style="margin-left: -15px">
												<h5 class="heading-primary mb-none">Tutorial cara pengerjaan web berbasis android 112234455</h5>
												<span>Oleh <a href="#" style="color: #000">John Doe</a> </span>
											</div>
										</div>
										<div class="row warnah jarak">
											<div class="col-md-3" style="margin-left: -8px">
												<a href="#"><img class="img-responsive img-circle mb-lg" src="../sets/img/projects/project-1.jpg" alt="Project Image">
											</div>
											<div class="col-md-9" style="margin-left: -15px">
												<h5 class="heading-primary mb-none">Tutorial cara pengerjaan web berbasis android 112234455</h5>
												<span>Oleh <a href="#" style="color: #000">John Doe</a> </span>
											</div>
										</div>
								</aside>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<aside class="sidebar" style=>
									<h3 class="heading-primary" style="margin-left: -10px"><strong>Kategori</strong>Tutorial</h3>
										<div class="row warnah jarak">
											<div class="col-md-2" style="padding-top: 10px ;">
												<a href="#"><img class="img-responsive img-circle mb-lg" src="../sets/img/projects/project-1.jpg" alt="Project Image">
											</div>
											<div class="col-md-10" style="margin-left: -15px">
												<h4 class="heading-primary mb-none">Web Programming</h4>
											</div>
										</div>
										<div class="row warnah jarak">
											<div class="col-md-2" style="padding-top: 5px ;">
												<a href="#"><img class="img-responsive img-circle mb-lg" src="../sets/img/projects/project-1.jpg" alt="Project Image">
											</div>
											<div class="col-md-10" style="margin-left: -15px">
												<h4 class="heading-primary mb-none">Destop Programming</h4>
											</div>
										</div>
										<div class="row warnah jarak">
											<div class="col-md-2" style="padding-top: 5px ;">
												<a href="#"><img class="img-responsive img-circle mb-lg" src="../sets/img/projects/project-1.jpg" alt="Project Image">
											</div>
											<div class="col-md-10" style="margin-left: -15px">
												<h4 class="heading-primary mb-none">PHP</h4>
											</div>
										</div>
										<div class="row warnah jarak">
											<div class="col-md-2" style="padding-top: 5px ;">
												<a href="#"><img class="img-responsive img-circle mb-lg" src="../sets/img/projects/project-1.jpg" alt="Project Image">
											</div>
											<div class="col-md-10" style="margin-left: -15px">
												<h4 class="heading-primary mb-none">MySQL</h4>
											</div>
										</div>
								</aside>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- Batas isi -->
