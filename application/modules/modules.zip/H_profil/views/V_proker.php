      <section class="page-header">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <ul class="breadcrumb">
                <li><a href="portofolio.html">Home</a></li>
              </ul>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <h1>Profil</h1>
            </div>
          </div>
        </div>
      </section>
      <!-- Bagian isi  -->
      <div class="container">
        <center><span><b>PROGRAM KERJA<br>EXPLORASI SOLIDARITAS MAHASISWA TEHNIK INFORMATIKA(EXOMATIK)<br>2016/2017</h2></b></span></center>
        <h4>Departement Kreatif & inovatif</h4>
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>
                No
              </th>
              <th>
                Nama Proker
              </th>
              <th>
                Detail
              </th>
              <th>
                Keterangan
              </th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
                1
              </td>
              <td>
                Mark
              </td>
              <td>
                Otto
              </td>
              <td>
                kredit
              </td>
            </tr>
            <tr>
              <td>
                2
              </td>
              <td>
                Jacob
              </td>
              <td>
                Thornton
              </td>
              <td>
                kredit
              </td>
            </tr>
            <tr>
              <td>
                3
              </td>
              <td>
                Larry
              </td>
              <td>
                the Bird
              </td>
              <td>
                kredit
              </td>
            </tr>
          </tbody>
        </table>
        <div class="divider divider-style-2 divider-icon-sm taller">
          <i class="fa fa-chevron-down"></i>
        </div>
        <h4>Departement Hubungan Masyarakat</h4>
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>
                No
              </th>
              <th>
                Nama Proker
              </th>
              <th>
                Detail
              </th>
              <th>
                Keterangan
              </th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
                1
              </td>
              <td>
                Mark
              </td>
              <td>
                Otto
              </td>
              <td>
                kredit
              </td>
            </tr>
            <tr>
              <td>
                2
              </td>
              <td>
                Jacob
              </td>
              <td>
                Thornton
              </td>
              <td>
                kredit
              </td>
            </tr>
            <tr>
              <td>
                3
              </td>
              <td>
                Larry
              </td>
              <td>
                the Bird
              </td>
              <td>
                kredit
              </td>
            </tr>
          </tbody>
        </table>
        <div class="divider divider-style-2 divider-icon-sm taller">
          <i class="fa fa-chevron-down"></i>
        </div>  
        <h4>Departement Pendidikan</h4>
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>
                No
              </th>
              <th>
                Nama Proker
              </th>
              <th>
                Detail
              </th>
              <th>
                Keterangan
              </th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
                1
              </td>
              <td>
                Mark
              </td>
              <td>
                Otto
              </td>
              <td>
                kredit
              </td>
            </tr>
            <tr>
              <td>
                2
              </td>
              <td>
                Jacob
              </td>
              <td>
                Thornton
              </td>
              <td>
                kredit
              </td>
            </tr>
            <tr>
              <td>
                3
              </td>
              <td>
                Larry
              </td>
              <td>
                the Bird
              </td>
              <td>
                kredit
              </td>
            </tr>
          </tbody>
        </table>
        <div class="divider divider-style-2 divider-icon-sm taller">
          <i class="fa fa-chevron-down"></i>
        </div>  
        <h4>Departement Keuangan</h4>
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>
                No
              </th>
              <th>
                Nama Proker
              </th>
              <th>
                Detail
              </th>
              <th>
                Keterangan
              </th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
                1
              </td>
              <td>
                Mark
              </td>
              <td>
                Otto
              </td>
              <td>
                kredit
              </td>
            </tr>
            <tr>
              <td>
                2
              </td>
              <td>
                Jacob
              </td>
              <td>
                Thornton
              </td>
              <td>
                kredit
              </td>
            </tr>
            <tr>
              <td>
                3
              </td>
              <td>
                Larry
              </td>
              <td>
                the Bird
              </td>
              <td>
                kredit
              </td>
            </tr>
          </tbody>
        </table>
        <div class="divider divider-style-2 divider-icon-sm taller">
          <i class="fa fa-chevron-down"></i>
        </div>  
        <h4>Departement Kesekretariatan</h4>
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>
                No
              </th>
              <th>
                Nama Proker
              </th>
              <th>
                Detail
              </th>
              <th>
                Keterangan
              </th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
                1
              </td>
              <td>
                Mark
              </td>
              <td>
                Otto
              </td>
              <td>
                kredit
              </td>
            </tr>
            <tr>
              <td>
                2
              </td>
              <td>
                Jacob
              </td>
              <td>
                Thornton
              </td>
              <td>
                kredit
              </td>
            </tr>
            <tr>
              <td>
                3
              </td>
              <td>
                Larry
              </td>
              <td>
                the Bird
              </td>
              <td>
                kredit
              </td>
            </tr>
          </tbody>
        </table>
        <div class="divider divider-style-2 divider-icon-sm taller">
          <i class="fa fa-chevron-down"></i>
        </div>    
      </div>
      <!-- batas sejarah -->  
