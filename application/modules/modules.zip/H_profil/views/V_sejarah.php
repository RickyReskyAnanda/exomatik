      <!-- Batas Header --> 
      <section class="page-header">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <ul class="breadcrumb">
                <li><a href="portofolio.html">Home</a></li>
              </ul>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <h1>Profil</h1>
            </div>
          </div>
        </div>
      </section>
      <!-- Bagian isi  -->
      <div style="margin-top: -35px;margin-bottom: -40px">
        <section class="parallax section section-parallax " data-stellar-background-ratio="0.5" style="background-image: url(&quot;img/parallax-transparent.jpg&quot;); background-position: 0% -36.5px;">
          <div class="container">
            <div class="row">
              <div class="col-md-8 col-md-offset-2">
                <center>
                <h2 class="mb-none text-dark">Sejarah Exomatik</h2>
                <h5 class="text-dark">Berdiri Tahun 2004</h5>
                </center>
                <p class="mb-none">EXOMATIK(Explorasi Solidaritas Teknik Informatika) didirikan pada 2 Desember 2004 oleh angkatan pertama Teknik Informatika UIN ALAUDDIN MAKASSAR yang dibimbing oleh dosen jurusan Teknik Informatika UIN ALAUDDIN MAKASSAR.<br>
                EXOMATIK didirikan karena adanya keterbatasan tentang apa yang didapat di dunia kampus, sehingga muncul inisiatif untuk membentuk Study Club sebagai wadah eksplorasi menyangkut dunia IT yang kemudian diberi nama EXOMATIK Study Club
                </p>
              </div>
            </div>
          </div>
        </section>
      </div>
      <!-- batas sejarah -->  
